/*global $*/
'use strict';

$(function (){
  // image stretches to fill container
  $('.imageContainer').imagefill();

  // breadcrumbs plugin
  $('#breadcrumbs').rcrumbs();

  //hide the rollover states
  //$('#computerOver').hide();


});
